Use OutlandAdventures;
INSERT INTO Guide(guide_name, specialization, employee_id)
    VALUES("Onward Climb Guide","Hiking",3);
INSERT INTO Guide(guide_name, specialization, employee_id)
    VALUES("Bucketlist Campers Guide","Camping",3);
INSERT INTO Guide(guide_name, specialization, employee_id)
    VALUES("Tent & Trails Guide","Camping",4);
INSERT INTO Guide(guide_name, specialization, employee_id)
    VALUES("Outdoor Odyssey Guide","Hiking",3);
INSERT INTO Guide(guide_name, specialization, employee_id)
    VALUES("TrekTopia Tour Guide","Hiking",4);
INSERT INTO Guide(guide_name, specialization, employee_id)
    VALUES("Camp The Woods","Camping",4);


SELECT * FROM Guide;
