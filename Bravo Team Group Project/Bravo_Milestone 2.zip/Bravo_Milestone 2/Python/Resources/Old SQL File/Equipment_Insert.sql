USE OutlandAdventures;
INSERT INTO Equipment(equipment_name,quantity)
    VALUES("Tent", 03);
INSERT INTO Equipment(equipment_name,quantity)
    VALUES("Lantern", 13);
INSERT INTO Equipment(equipment_name,quantity)
    VALUES("Camp Stove", 6);
INSERT INTO Equipment(equipment_name,quantity)
    VALUES("Flashlight", 35);
INSERT INTO Equipment(equipment_name,quantity)
    VALUES("Cooler", 20);
INSERT INTO Equipment(equipment_name,quantity)
    VALUES("First Aid Kit", 16);

Select * from Equipment;