INSERT INTO Product(product_name, product_price, product_quantity)
    VALUES("Outdoor Hiking Backpack", 45.00, 12);
INSERT INTO Product(product_name, product_price, product_quantity)
    VALUES("Trekking Poles", 39.99, 10);
INSERT INTO Product(product_name, product_price, product_quantity)
    VALUES("Tent", 248.39, 15);
INSERT INTO Product(product_name, product_price, product_quantity)
    VALUES("Camping Survival Kit", 45.87, 23);
INSERT INTO Product(product_name, product_price, product_quantity)
    VALUES("Cooler", 179.99, 10);
INSERT INTO Product(product_name, product_price, product_quantity)
    VALUES("Hammock", 39.99, 23);

Select * FROM Product;